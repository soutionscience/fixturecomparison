(function(){
  angular.module('fixApp', [])

  var kitu ="iko hapa"
})();