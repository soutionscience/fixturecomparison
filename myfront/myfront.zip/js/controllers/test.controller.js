(function(){
	angular.module('fixApp')
	.controller('testCtrl', testCtrl)
   
   testCtrl.$inject =['$scope'];


	function testCtrl($scope){




	}


})();