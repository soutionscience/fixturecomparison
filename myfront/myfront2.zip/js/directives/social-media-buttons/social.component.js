(function(){
	angular.module('fixApp')
	.component('socialMedia', {

		templateUrl: 'views/content/socialMedia.template.html'

	})

})();