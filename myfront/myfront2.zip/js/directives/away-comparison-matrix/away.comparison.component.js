(function(){
	'use restrict';


	angular.module('fixApp')
	.component('awaycomparisonMatrix', {

		templateUrl: 'views/content/away.comparison.template.html'
	  //  bindings:{
		 // 	myItemList: '<'
		 // }
	})

})();