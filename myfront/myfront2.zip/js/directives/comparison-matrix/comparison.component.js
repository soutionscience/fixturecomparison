(function(){
	'use restrict';


	angular.module('fixApp')
	.component('comparisonMatrix', {

		templateUrl: 'views/content/comparison.template.html'
	  //  bindings:{
		 // 	myItemList: '<'
		 // }
	})

})();